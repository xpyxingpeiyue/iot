package com.tenet.iot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tenet.iot.lock.TtSyncLock;

public interface SyncLockMapper extends BaseMapper<TtSyncLock> {
}
