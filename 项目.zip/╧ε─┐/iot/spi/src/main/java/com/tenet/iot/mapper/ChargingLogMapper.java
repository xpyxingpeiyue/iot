package com.tenet.iot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tenet.iot.parking.TtChargingLog;

public interface ChargingLogMapper extends BaseMapper<TtChargingLog> {
}
