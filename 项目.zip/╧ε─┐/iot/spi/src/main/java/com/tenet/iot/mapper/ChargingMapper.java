package com.tenet.iot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tenet.iot.parking.TtCharging;

public interface ChargingMapper extends BaseMapper<TtCharging> {
}
