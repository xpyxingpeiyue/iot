package com.tenet.iot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.tenet.iot.system.TtMember;

public interface MemberMapper extends BaseMapper<TtMember> {
}
